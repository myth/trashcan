Øvingen har frist fredag 17. april klokken 18.00
Øvingen må demonstreres på sal før denne tiden. 

Test programmet med forskjellige verdier. 
Vær forberedt på spørsmål om hva som skjer når man endrer verdiene.